import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import Home from './Home';
import Items from './Items';
import Navbar from './Navbar';

function App() {
  return (
    <div>
      <BrowserRouter>
        <Navbar/>
        <Routes>
          <Route path='/' element={<Home/>}/>
          <Route path='/items' element={<Items/>}/>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;

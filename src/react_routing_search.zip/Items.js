import { useEffect, useState } from "react"

function Items() {
    const [list, setList] = useState([])
    const [searchTerm, setSearchTerm] = useState("")
    const [filteredList, setFilteredList] = useState([])

    useEffect(() => {
        if(list.length === 0) {
            const item1 = {
                title: "google",
                content: "https://www.google.com"
            }
            const item2 = {
                title: "w3schools",
                content: "https://www.w3schools.com"
            }
            const item3 = {
                title: "openai",
                content: "https://openai.com"
            }
    
            setList([item1, item2, item3])
            setFilteredList([item1, item2, item3])
        }

        if(searchTerm !== "") {
            let tempfilteredList = list.filter((item) => item.title.toLowerCase().includes(searchTerm.toLowerCase()))
            setFilteredList(tempfilteredList)
        }
        
    }, [searchTerm, list])

    return (
        <div>
            <div>
                <input type="text" onChange={(e) => setSearchTerm(e.target.value)} value={searchTerm}></input>
            </div>
            {
                filteredList.map((item, index) => 
                    <li key={index}>
                        <a href={item.content}>{item.title}</a>
                    </li>
                )
            }
        </div>
    )
}
export default Items